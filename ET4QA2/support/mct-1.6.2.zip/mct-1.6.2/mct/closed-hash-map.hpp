// Back-compatibility header.
#warning <mct/closed-hash-map.hpp> is deprecated; use <mct/hash-map.hpp> instead
#include <mct/hash-map.hpp>
