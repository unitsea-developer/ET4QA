// Back-compatibility header.
#warning <mct/closed-hash-set.hpp> is deprecated; use <mct/hash-set.hpp> instead
#include <mct/hash-set.hpp>
